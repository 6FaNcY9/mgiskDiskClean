{
  pkgs,
  lib,
  config,
  inputs,
  ...
}:
{
  packages = with pkgs; [
    nginx
    jq
    curl
    apacheHttpd
  ];

  scripts = {
    scan-upload.exec = ''
      echo "Uploading scripts to server..."
      scp $DEVENV_ROOT/scripts/maildir_scan.py mrija_org@s16.thehost.com.ua:~/
      scp $DEVENV_ROOT/scripts/disk_scan.py mrija_org@s16.thehost.com.ua:~/
      echo "Done. SSH in and run:"
      echo "  python ~/maildir_scan.py email/mrija.org/<mailbox>/.maildir"
      echo "  python ~/disk_scan.py /var/www/mrija_org/data"
    '';
    pull-report.exec = ''
      if [ -z "$1" ]; then
        echo "Usage: pull-report email/mrija.org/<mailbox>/.maildir"
        exit 1
      fi
      REMOTE="/var/www/mrija_org/data/$1/../mail_report.html"
      scp mrija_org@s16.thehost.com.ua:"$REMOTE" $DEVENV_ROOT/reports/index.html
      echo "Deployed to reports/index.html — run serve-reload"
    '';
    pull-disk-report.exec = ''
      scp mrija_org@s16.thehost.com.ua:~/disk_report.html $DEVENV_ROOT/reports/index.html
      echo "Deployed disk report — run serve-reload"
    '';
    deploy-report.exec = ''
      if [ -z "$1" ]; then
        echo "Usage: deploy-report /path/to/report.html"
        exit 1
      fi
      cp "$1" $DEVENV_ROOT/reports/index.html
      echo "Deployed. Run serve-reload."
    '';
    set-password.exec = ''
      htpasswd -c $DEVENV_ROOT/nginx/.htpasswd boss
      echo "Done. Run serve-reload."
    '';
    serve-start.exec  = "nginx -c $DEVENV_ROOT/nginx/nginx.conf -p $DEVENV_ROOT";
    serve-stop.exec   = "nginx -c $DEVENV_ROOT/nginx/nginx.conf -p $DEVENV_ROOT -s stop";
    serve-reload.exec = "nginx -c $DEVENV_ROOT/nginx/nginx.conf -p $DEVENV_ROOT -s reload";
  };

  enterShell = ''
    echo ""
    echo "  mgiskDiskClean devenv"
    echo "  ──────────────────────────────────────────"
    echo "  scan-upload              upload scripts to server"
    echo "  pull-report <maildir>    pull mail_report.html from server"
    echo "  pull-disk-report         pull disk_report.html from server"
    echo "  deploy-report <file>     deploy local html to reports/"
    echo "  set-password             set boss nginx password"
    echo "  serve-start              start nginx :8765"
    echo "  serve-stop               stop nginx"
    echo "  serve-reload             reload nginx config"
    echo ""
    echo "  reports : $DEVENV_ROOT/reports/"
    echo "  logs    : $DEVENV_ROOT/logs/"
    echo ""
  '';
}
